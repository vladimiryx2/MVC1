using Microsoft.AspNetCore.Mvc;

namespace pruebaMVC.Controllers{
     
     public class AuthController:Controller{
       
       public IActionResult Index(){
            return View();
        }
        public IActionResult Register(){
            return View();
        }
        

    }

}