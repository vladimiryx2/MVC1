using Microsoft.AspNetCore.Mvc;

namespace pruebaMVC.Controllers{
    

    public class UserController : Controller{
        public IActionResult Index(){
            return View();
        }
         public IActionResult UpdateUser(){
            return View();
        }
    }
}


