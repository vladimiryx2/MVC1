using Microsoft.AspNetCore.Mvc;

namespace pruebaMVC.Controllers{
     
     public class ProductController:Controller{
       
       public IActionResult Index(){
            return View();
        }
        public IActionResult CreateNewProduct(){
            return View();
        }
         public IActionResult UpdateProduct(){
            return View();
        }
        

    }

}

    
